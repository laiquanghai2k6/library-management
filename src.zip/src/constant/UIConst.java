package constant;

public class UIConst {
    public static final double WINDOW_WIDTH = 600;
    public static final double WINDOW_HEIGHT = 400;
}
